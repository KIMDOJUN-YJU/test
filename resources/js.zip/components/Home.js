import React, { Component } from "react";
import { BrowserRouter as Router } from "react-router-dom";

import { MDBNavLink, MDBMask, MDBRow, MDBCol, MDBIcon, MDBBtn, MDBView, MDBContainer } from "mdbreact";
import { store } from 'react-notifications-component';
import 'react-notifications-component/dist/theme.css';
import 'animate.css';
import Header from '../layout/Header'
import Footer from '../layout/Footer'
// import { ToastContainer, toast } from 'react-toastify';
import "../style/index.css";




class Home extends React.Component {
state = {
collapseID: ""
};

toggleCollapse = collapseID => () =>
this.setState(prevState => ({
collapseID: prevState.collapseID !== collapseID ? collapseID : ""
}));

render() {
const overlay = (
<div id="sidenav-overlay" style={{ backgroundColor: "transparent" }} onClick={this.toggleCollapse("navbarCollapse")} />
);
return (
      <div id="videobackground">
        <Header/>
        <MDBView>
          <video className="video-intro" poster="https://mdbootstrap.com/img/Photos/Others/background.jpg" playsInline
            autoPlay muted="" loop>
            <source src="https://mdbootstrap.com/img/video/animation.mp4" type="video/mp4" />
          </video>
          <MDBMask className="d-flex justify-content-center align-items-center gradient">
            <MDBContainer className="px-md-3 px-sm-0">
              <MDBRow>
                <MDBCol md="12" className="mb-4 white-text text-center">
                  <h3 className="display-3 font-weight-bold mb-0 pt-md-5">
                    {"Comfortable travel"}
                  </h3>
                  <hr className="hr-light my-4 w-75" />
                  <h4 className="subtext-header mt-2 mb-4">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit
                    deleniti consequuntur nihil.
                  </h4>
                  <MDBBtn outline rounded color="white">
                      <MDBIcon icon="home" /><MDBNavLink to="/keeper_register">keeper_create</MDBNavLink>
                  </MDBBtn>
                </MDBCol>
              </MDBRow>
            </MDBContainer>
          </MDBMask>
        </MDBView>
        <div className="container-fluid" style={{borderTop: '3px solid #808080'}}>
            <div className="row">
                <div className="col-sm-12 text-center" style={{ marginTop: '30px'}}>
                    <p className="h1">Dokonimo의 특징</p>
                </div>
            </div>
            <div className="container">
                <div className="row">
                    <div className="col-md-4"><img src="1.png" alt="" height="200px" width="300px" /></div>
                    <div className="col-md-4"><img src="2.png" alt="" height="200px" width="300px" /></div>
                    <div className="col-md-4"><img src="3.png" alt="" height="200px" width="300px" /></div>
                </div>
                <div className="row text-center" style={{ marginTop: '30px'}}>
                    <div className="col-md-4 h3">스마트 폰의 사전 예약</div>
                    <div className="col-md-4 h3">유료 사물함 대신에</div>
                    <div className="col-md-4 h3">가벼운 몸으로 관광</div>
                </div>
            </div>
        </div>
        <div className="container text-center mt-3">
          <button
          onClick={() => {
            store.addNotification({
              
              title: 'Dokonimo',
              message: 'Have a reservation',
              type: 'danger',                         // 'default', 'success', 'info', 'warning'
              container: 'top-right',                // where to position the notifications
              animationIn: ["animated", "fadeIn"],     // animate.css classes that's applied
              animationOut: ["animated", "fadeOut"],   // animate.css classes that's applied
              dismiss: {
                duration: 5000,
                onScreen: true,
                timingFunction: 'ease-out',
                delay: 0
              },
              // swipe: {
              //   duration: 400,
              //   timingFunction: 'ease-out',
              //   delay: 0,
              // },
              // fade: {
              //   duration: 400,
              //   timingFunction: 'ease-out',
              //   delay: 0
              // },
              // slidingExit: {
              //   duration: 800,
              //   timingFunction: 'ease-out',
              //   delay: 0
              // },
            })
          }}>
            <h1>Reserve</h1>
          </button>
        </div>
        
      
        <Footer/>
      </div>
    );
  }
}



export default Home;