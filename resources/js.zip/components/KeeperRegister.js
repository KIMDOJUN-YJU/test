import React from 'react';
import { UserForm } from '../register/UserForm';

const KeeperRegister = () => {
    return (
        <div>
            <UserForm />
        </div>
    );
};

export default KeeperRegister;