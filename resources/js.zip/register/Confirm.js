import React, { Component } from 'react';
import Dialog from '@material-ui/core/Dialog';
import AppBar from '@material-ui/core/AppBar';
import { ThemeProvider as MuiThemeProvider } from '@material-ui/core/styles';
import { List, ListItem, ListItemText } from '@material-ui/core/';
import Button from '@material-ui/core/Button';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import IconButton from '@material-ui/core/IconButton';
import MenuIcon from '@material-ui/icons/Menu';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';

export class Confirm extends Component {
  continue = e => {
    e.preventDefault();
    // PROCESS FORM //
    this.props.nextStep();
  };

  back = e => {
    e.preventDefault();
    this.props.prevStep();
  };

  render() {
    const {
      values: { firstName, lastName, email, occupation, city, bio }
    } = this.props;
    return (
      <MuiThemeProvider>
        <>
          <Dialog
            open
            fullWidth
            maxWidth='sm'
          >
            <AppBar position="static">
              <Toolbar>
                <IconButton edge="start" color="inherit" aria-label="menu">
                  <MenuIcon />
                </IconButton>
                <Typography variant="h6">
                Keeper Register
                </Typography>
                {/* <Button color="inherit">Login</Button> */}
              </Toolbar>
            </AppBar>
            <br />

            <FormControlLabel
              control={
                <Checkbox
                  color="primary"
                />
              }
              label="가게의 영업 시간은 반드시 직원이 상주하고 있다."
            />
            <FormControlLabel
              control={
                <Checkbox
                  color="primary"
                />
              }
              label="카메라 기능의 인터넷 단말기(스마트폰, 태블릿 등)가 있다."
            />
            <FormControlLabel
              control={
                <Checkbox
                  color="primary"
                />
              }
              label="유흥업소 등의 가게에 해당되지 않는다."
            />
            <FormControlLabel
              control={
                <Checkbox
                  color="primary"
                />
              }
              label="사행성이 높은 행위를 제공하는 가게에 해당되지 않는다."
            />
            <FormControlLabel
              control={
                <Checkbox
                  color="primary"
                />
              }
              label="종교 관련 시설이 아니다."
            />
            <br />
            <FormControlLabel
              control={
                <Checkbox
                  color="primary"
                />
              }
              label="서비스 이용 약관에 동의합니다."
            />

            <br />
            <Button
              color="secondary"
              variant="contained"
              onClick={this.back}
            >Back</Button>

            <Button
              color="primary"
              variant="contained"
              onClick={this.continue}
            >Confirm & Continue</Button>
          </Dialog>
        </>
      </MuiThemeProvider>
    );
  }
}

export default Confirm;
