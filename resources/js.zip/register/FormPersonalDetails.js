import React, { Component, useState } from 'react';
import Dialog from '@material-ui/core/Dialog';
import AppBar from '@material-ui/core/AppBar';
import { ThemeProvider as MuiThemeProvider } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import InputLabel from '@material-ui/core/InputLabel';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import IconButton from '@material-ui/core/IconButton';
import MenuIcon from '@material-ui/icons/Menu';
import Fab from "@material-ui/core/Fab";
import AddPhotoAlternateIcon from "@material-ui/icons/AddPhotoAlternate";


export class FormPersonalDetails extends Component {

  
  continue = e => {
    e.preventDefault();
    this.props.nextStep();
  };

  back = e => {
    e.preventDefault();
    this.props.prevStep();
  };

  

  render() {
    const { values, handleChange } = this.props;
    
    return (
      
      <MuiThemeProvider>
        <>
          <Dialog
            open
            fullWidth
            maxWidth='sm'
          >
            <AppBar position="static">
              <Toolbar>
                <IconButton edge="start" color="inherit" aria-label="menu">
                  <MenuIcon />
                </IconButton>
                <Typography variant="h6">
                Keeper Register
                </Typography>
                {/* <Button color="inherit">Login</Button> */}
              </Toolbar>
            </AppBar>

            <TextField
              placeholder="ex) DOKONIMO Cafe"
              label="Keeper Name"
              onChange={handleChange('text')}
              defaultValue={values.occupation}
              margin="normal"
              fullWidth
            />

            <FormControl
            margin="normal"
            fullWidth>
              <InputLabel id="demo-simple-select-label">City</InputLabel>
              <Select
                onChange={handleChange}
                margin="normal"
                fullWidth
              >
                <MenuItem value={1}>Seoul</MenuItem>
                <MenuItem value={2}>Daegu</MenuItem>
                <MenuItem value={3}>Busan</MenuItem>
                <MenuItem value={4}>Daejeon</MenuItem>
                <MenuItem value={5}>Ulsan</MenuItem>
              </Select>
            </FormControl>
            
            <TextField
              placeholder="ex) 대구광역시 달서구 선원남로 151"
              label="Enter Detail Address"
              onChange={handleChange('city')}
              defaultValue={values.city}
              margin="normal"
              fullWidth
            />

            <TextField
            margin="normal"
            fullWidth
              label="Off Day"
              type="date"
              defaultValue="2020-05-23"
              InputLabelProps={{
                shrink: true,
              }}
            />

            <TextField
            margin="normal"
            fullWidth
              label="Open Time"
              type="time"
              defaultValue="09:30"
              InputLabelProps={{
                shrink: true,
              }}
              inputProps={{
                step: 300,
              }}
            />

            <TextField
            margin="normal"
            fullWidth
              label="Close Time"
              type="time"
              defaultValue="22:30"
              InputLabelProps={{
                shrink: true,
              }}
              inputProps={{
                step: 300,
              }}
            />

            <FormControl
            margin="normal"
            fullWidth>
              <InputLabel id="demo-simple-select-label">Bag</InputLabel>
              <Select
                onChange={handleChange}
                margin="normal"
                fullWidth
              >
                <MenuItem value={1}>1</MenuItem>
                <MenuItem value={2}>2</MenuItem>
                <MenuItem value={3}>3</MenuItem>
                <MenuItem value={4}>4</MenuItem>
                <MenuItem value={5}>More than 4</MenuItem>
              </Select>
            </FormControl>

            <FormControl
            margin="normal"
            fullWidth>
              <InputLabel id="demo-simple-select-label">Luggage</InputLabel>
              <Select
                onChange={handleChange}
              >
                <MenuItem value={1}>1</MenuItem>
                <MenuItem value={2}>2</MenuItem>
                <MenuItem value={3}>3</MenuItem>
                <MenuItem value={4}>4</MenuItem>
                <MenuItem value={5}>More than 4</MenuItem>
              </Select>
            </FormControl>
            <br />

            <input
              accept="image/*"
              id="contained-button-file"
              multiple
              type="file"
              onChange={this.handleUploadClick}
            />
            <label htmlFor="contained-button-file">
              <Fab component="span">
                <AddPhotoAlternateIcon />
              </Fab>
            </label>


            

            <br />
            <Button
              color="secondary"
              variant="contained"
              onClick={this.back}
            >Back</Button>

            <Button
              color="primary"
              variant="contained"
              onClick={this.continue}
            >Next</Button>
          </Dialog>
        </>
      </MuiThemeProvider>
    );
  }
}


export default FormPersonalDetails;
