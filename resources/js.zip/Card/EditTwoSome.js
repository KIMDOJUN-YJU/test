import React, { Component } from 'react';
import axios from 'axios';
import {Link} from 'react-router-dom';
import LeftSideBar from '../animations/LeftSideBar';

class EditTwoSome extends Component{
  constructor(props){
    super(props);
    this.state = {
      keeper_store_name:'',
      keeper_store_address:'',
      keeper_store_tel:'',
      keeper_store_openinghours:'',
      keeper_store_bag_cnt:'',
      keeper_store_car_cnt:''
    }

    this.handleInputChange = this.handleInputChange.bind(this);
  }

  componentWillMount(){
    this.getTwosomeDetails();
  }

  getTwosomeDetails(){
    axios.get('/api/kstoreinfos/2')
    .then(response => {
      this.setState({
        keeper_store_name:response.data.keeper_store_name,
        keeper_store_address:response.data.keeper_store_address,
        keeper_store_tel:response.data.keeper_store_tel,
        keeper_store_openinghours:response.data.keeper_store_openinghours,
        keeper_store_bag_cnt:response.data.keeper_store_bag_cnt,
        keeper_store_car_cnt:response.data.keeper_store_car_cnt
      }, () => {
        console.log(this.state);
      });
    })
    .catch(err => console.log(err));
    }

  editTwosome(newTwosome){
    axios.request({
      method:'put',
      url:'/api/kstoreinfos/2',
      data: newTwosome
    }).then(response => {
      this.props.history.push('/keepermenu/keepermanagement');
    }).catch(err => console.log(err));
  }

  onSubmit(e){
    const newTwosome = {
        keeper_store_name: this.refs.keeper_store_name.value,
        keeper_store_address: this.refs.keeper_store_address.value,
        keeper_store_tel: this.refs.keeper_store_tel.value,
        keeper_store_openinghours: this.refs.keeper_store_openinghours.value,
        keeper_store_bag_cnt: this.refs.keeper_store_bag_cnt.value,
        keeper_store_car_cnt: this.refs.keeper_store_car_cnt.value
    }
    this.editTwosome(newTwosome);
    e.preventDefault();
  }

  handleInputChange(e){
    const target = e.target;
    const value = target.value;
    const name = target.name;

    this.setState({
      [name]: value
    });
  }

  render(){
    return (
     <div>
       <LeftSideBar />
       <h1>썬더치킨 동대구역점 정보수정</h1>
       <form onSubmit={this.onSubmit.bind(this)}>
          <div className="input-field">
            <label htmlFor="keeper_store_name">가게이름</label>
            <input type="text" name="keeper_store_name" ref="keeper_store_name" value={this.state.keeper_store_name} onChange={this.handleInputChange} />
          </div>
          <div className="input-field">
            <label htmlFor="keeper_store_address">가게주소</label>
            <input type="text" name="keeper_store_address" ref="keeper_store_address" value={this.state.keeper_store_address} onChange={this.handleInputChange} />
          </div>
          <div className="input-field">
            <label htmlFor="keeper_store_tel">전화번호</label>  
            <input type="text" name="keeper_store_tel" ref="keeper_store_tel" value={this.state.keeper_store_tel} onChange={this.handleInputChange} />
          </div>
          <div className="input-field">
            <label htmlFor="keeper_store_tel">전화번호</label>
            <input type="text" name="keeper_store_openinghours" ref="keeper_store_openinghours" value={this.state.keeper_store_openinghours} onChange={this.handleInputChange} />
          </div>
          <div className="input-field">
            <label htmlFor="keeper_store_bag_cnt">가방개수</label>
            <input type="text" name="keeper_store_bag_cnt" ref="keeper_store_bag_cnt" value={this.state.keeper_store_bag_cnt} onChange={this.handleInputChange} />
          </div>
          <div className="input-field">
            <label htmlFor="keeper_store_car_cnt">캐리어개수</label>
            <input type="text" name="keeper_store_car_cnt" ref="keeper_store_car_cnt" value={this.state.keeper_store_car_cnt} onChange={this.handleInputChange} />
          </div>
          <input type="submit" value="Save" className="btn" />
        </form>
      </div>
    )
  }
}

export default EditTwoSome;