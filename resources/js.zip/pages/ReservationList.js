import React, { Component,useState,Fragment } from 'react';
import axios from 'axios'
import LeftSideBar from '../animations/LeftSideBar';

class ReservationList extends Component {

  constructor(){
    super();
    this.state = {
      reserve:[]
    }
  }
  componentWillMount(){
    this.getReserve();
  }
  getReserve(){
    axios.get('/api/rtshow/1')
    .then(response => {
      this.setState({
        reserve: response.data
      }, () => {
        console.log(this.state);
      });
    })
    .catch(err => console.log(err));
    }

  // _renderCalendar = () => {
  //   const Mycalendar =  this.state.reserves.map(data => { //array.map() 새로운 배열 생성
  //          return <MyCalendar
  //          key={data.reservation_id}  
  //          title={data.tourist_name}
  //          start={data.check_in}
  //          end={data.check_out} 
  //          />
  //   })
  //   return console.log("asdfasdf");
  // }

  _renderCalendar () {
    alert('asdfasdf!!')
  }


  render(){
      return (
        <div>
          <LeftSideBar />
          <div className="container text-center mb-5">
            <h1>Reservation</h1>
          </div>
          <table className="table table-sm">
            <thead>
              <tr>
                <th scope="col">Id</th>
                <th scope="col">Name</th>
                <th scope="col">Phone_Number</th>
                <th scope="col">check_in</th>
                <th scope="col">check_out</th>
                <th scope="col">Bag</th>
                <th scope="col">Car</th>
                <th scope="col">Button</th>
              </tr>
            </thead>
            <tbody>
              {this.state.reserve.map((item, index) => (
                <tr key={index}>
                  <th scope="row">{item.reservation_id}</th>
                      <td>{item.tourist_name}</td>
                      <td>{item.tourist_phonenumber}</td>
                      <td>{item.check_in}</td>
                      <td>{item.check_out}</td>
                      <td>{item.bag_cnt}</td>
                      <td>{item.car_cnt}</td>
                      <td scope="row">
                        <button type="button" className="btn btn-teal btn-rounded btn-sm" onClick={this._renderCalendar.bind(this)}>Yes</button>
                        <button type="button" className="btn btn-teal btn-rounded btn-sm">No</button>
                      </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
       );
  }
};

export default ReservationList;
