// import React from 'react'
// import { makeStyles } from '@material-ui/core/styles'
// import Paper from '@material-ui/core/Paper'
// import CardMatome from '../Card/CardMatome'

// const useStyles = makeStyles((theme) => ({
//     root: {
//       display: 'flex',
//       alignItems:'center',
//       justifyContent:'center',
//       '& > *': {
//         margin: theme.spacing(5),
//         width: theme.spacing(200),
//         height: theme.spacing(95),
//       },
//     },
//   }));

// const KeeperManagement = () => {
//     const classes = useStyles();
//     return (
//         <div className={classes.root}>
//             <Paper variant="outlined" square>
//                 <CardMatome />
//             </Paper>
//         </div>
//     );
// };

// export default KeeperManagement;
import React from 'react'
import {Link, Route, BrowserRouter} from 'react-router-dom'
import { makeStyles } from '@material-ui/core/styles'
import { MDBBtn } from "mdbreact";
import '../../../node_modules/mdbreact/dist/css/mdb.css'
import CardMatome from '../Card/CardMatome'
import LeftSideBar from '../animations/LeftSideBar';

const useStyles = makeStyles((theme) => ({
  plus: {
    marginLeft:"940px",
    marginTop:"70px",
  },
}));

const KeeperManagement = () => {
    const classes = useStyles();

    return (
        <div>
          <LeftSideBar />
          <CardMatome />
          <MDBBtn href="/keeper_register" gradient="aqua" className={classes.plus}>추가</MDBBtn>
        </div>
    );
};

export default KeeperManagement;