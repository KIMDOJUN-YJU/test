import React from 'react';
import LeftSideBar from '../animations/LeftSideBar';

const Others = () => {
    return (
        <div>
            <LeftSideBar />
            <h1>Others</h1>
        </div>
    );
};

export default Others;