import React from 'react';
import LeftSideBar from '../animations/LeftSideBar';

const Profile = () => {
    return (
        <div>
            <LeftSideBar />
            <h1>Profile</h1>
        </div>
    );
};

export default Profile;