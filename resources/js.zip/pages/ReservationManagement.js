import React,{ Component } from 'react';
import { Calendar } from '@fullcalendar/core';
import FullCalendar from '@fullcalendar/react';
import dayGridPlugin from '@fullcalendar/daygrid';
import interactionPlugin from "@fullcalendar/interaction";
import resourceTimelinePlugin from '@fullcalendar/resource-timeline'
import calendarPlugins from '@fullcalendar/google-calendar'
import LeftSideBar from '../animations/LeftSideBar';
import '../style/App.css';
import PropTypes from 'prop-types';

class ReservationManagement extends React.Component {

  static propTypes = {
    title : PropTypes.string.isRequired,
    end : PropTypes.string.isRequired,
    start : PropTypes.string.isRequired
  }

  componentWillMount(){
    this.setState({
      events : []
    });
  }

  componentDidMount(){
    this.callApi()
      .then(res => this.setState({events:res}))
      .catch(err => console.log(err));
  }
  callApi = async () => {
    const response = await fetch('/api/rtshow/1');
    const body = await response.json();
    return body;
  }

  

  calendarRef = React.createRef()
  render(){
    const {events} = this.props;
    return(
      <div>
        <LeftSideBar />
      {/* {this.state.events.map((event)=>{
        return (
          <FullCalendar 
          defaulView="dayGridMonth" 
          dateClick={this.handleDateClick}
          schedulerLicenseKey="GPL-My-Project-Is-Open-Source"
          ref={this.calendarRef}
          plugins={[dayGridPlugin,interactionPlugin,resourceTimelinePlugin,calendarPlugins]}
          editable={true}
          eventDrop={this.handleEventDrop}
          eventClick={this.handleEventClick}
          // events={this.formatEvents()}
          events={[
            {title:event.tourist_name,date:event.check_in}
          ]}
        />
        )
      })} */}
        <FullCalendar 
            defaulView="dayGridMonth" 
            dateClick={this.handleDateClick}
            schedulerLicenseKey="GPL-My-Project-Is-Open-Source"
            ref={this.calendarRef}
            plugins={[dayGridPlugin,interactionPlugin,resourceTimelinePlugin,calendarPlugins]}
            editable={true}
            eventDrop={this.handleEventDrop}
            eventClick={this.handleEventClick}
            events={this.formatEvents()}
            // events={[
            //   {title:this.props.title,date:this.props.check_in}
            // ]}
          />
      </div>
    );
  }

  formatEvents() {
  return this.state.events.map(appointment => {
            const {title, end, start} = appointment

            let startTime = new Date(start)
            let endTime = new Date(end)

            return {
              title, 
              start: startTime,
              end: endTime, 
              extendedProps: {...appointment}
            }
        })
  }

  handleEventClick = (arg) => { // bind with an arrow function
    alert(arg.dateStr)
  }

  someMethod() {
    let calendarApi = this.calendarRef.current.getApi()
    calendarApi.next()
  }
}
export default ReservationManagement;